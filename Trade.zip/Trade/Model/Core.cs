﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trade.Model
{
    public class Core
    {
        public readonly TradeEntities context = new TradeEntities();
    }
}
