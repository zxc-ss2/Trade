﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trade.Model
{
    public partial class Product
    {
        public byte[] CustomImage
        {
            get
            {
                string fullAppPath = Directory.GetCurrentDirectory();
                string localAppPath = fullAppPath.Replace(@"\bin\Debug", "");

                if (ProductPhotoPath != null && ProductPhoto == null)
                {
                    if (new FileInfo(localAppPath + @"\Assets\Images\Products\" + ProductPhotoPath).Exists)
                    {
                        return File.ReadAllBytes(localAppPath + @"\Assets\Images\Products\" + ProductPhotoPath);
                    }

                    else 
                    { 
                        return File.ReadAllBytes(localAppPath + @"\Assets\Images\picture.png");
                    }
                }

                else
                {
                    return ProductPhoto;
                }

            }
        }

        public string Name
        {
            get
            {
                return ProductName;
            }
        }

        public string Description
        {
            get
            {
                return ProductDescription;
            }
        }

        public string Manufacturer
        {
            get
            {
                return ProductManufacturer;
            }
        }

        public decimal Price
        {
            get
            {
                return ProductCost;
            }
        }

        public int Quantity
        {
            get
            {
                return ProductQuantityInStock;
            }
        }
    }
}
