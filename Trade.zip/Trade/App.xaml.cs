﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Trade
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static bool adminCheck = false;
        public static bool managerCheck = false;
        public static bool clientCheck = false;
        public static string userLogin = "";
        public static string userPassword = "";
    }
}
